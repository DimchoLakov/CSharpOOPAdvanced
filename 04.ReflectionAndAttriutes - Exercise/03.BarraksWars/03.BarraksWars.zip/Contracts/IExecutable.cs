﻿public interface IExecutable
{
    string Execute();
}