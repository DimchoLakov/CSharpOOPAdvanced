﻿public interface IAdditionalStats
{
    int Strength { get; }

    int Agility { get; }

    int Vitality { get; }
}