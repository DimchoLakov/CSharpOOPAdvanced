﻿public interface ITrafficLight
{
    void ChangeLights();
}