﻿public interface IKing : IBoss, IAttackable, INamable
{

}