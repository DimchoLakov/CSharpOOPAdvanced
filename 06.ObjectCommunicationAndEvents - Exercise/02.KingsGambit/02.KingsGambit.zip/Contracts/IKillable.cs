﻿public interface IKillable
{
    bool isAlive { get; }

    void Die();
}