﻿[SoftUni("Dimcho")]
public class StartUp
{
    [SoftUni("Lakov")]
    public static void Main()
    {
        Tracker tracker = new Tracker();
        tracker.PrintMethodsByAuthor();
    }
}