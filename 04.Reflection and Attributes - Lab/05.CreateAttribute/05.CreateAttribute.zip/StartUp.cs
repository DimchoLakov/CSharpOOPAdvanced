﻿using System;

[SoftUni("Dimcho")]
public class StartUp
{
    [SoftUni("Lakov")]
    public static void Main()
    {

    }
}