﻿public class ObserveTarget : IObservableTarget
{
    public void ReceiveDamage(int damage)
    {
        throw new System.NotImplementedException();
    }

    public bool IsDead { get; }
    public void Update(int value)
    {

        throw new System.NotImplementedException();
    }
}