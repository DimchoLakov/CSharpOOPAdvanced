﻿public interface ICommand
{
    void Execute();
}