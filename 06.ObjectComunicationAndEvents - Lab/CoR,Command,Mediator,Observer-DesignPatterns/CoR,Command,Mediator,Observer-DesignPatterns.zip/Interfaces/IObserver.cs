﻿public interface IObserver
{
    void Update(int value);
}